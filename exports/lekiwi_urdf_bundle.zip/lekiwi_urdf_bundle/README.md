# LeKiwi + SO101 최신 모델 번들

2026-09-30 기준 `lekiwi/feature/lekiwi-ros2` 작업본의 교육용 모델과 카메라 좌표계 스냅샷입니다.

## 열기

압축을 풀고 `lekiwi_soarm.urdf`를 엽니다. `meshes/`는 URDF와 같은 폴더에 둡니다.
모든 mesh 참조는 상대 경로이며 ROS package 경로나 원래 PC의 절대 경로가 필요하지 않습니다.

## 포함한 모델

- 교육용 `lekiwi_body_soarm_mount.stl` 몸체, omni wheel 3개, SO101 팔과 교육용 팔 장착 위치.
- 전방 `base_link → front_camera_optical_frame`, 손목 `wrist_link → wrist_camera_optical_frame`.
- 교육용 카메라 상자와 렌즈 외형, 원본 `camera_mounts.json` 설정.
- `base_footprint → base_link`: (0, 0, 0.075) m. 기준 높이는 바퀴 접지면입니다.
- 기본 내보내기는 18개 link, 17개 joint입니다. `--hardware-sensors` 내보내기는 lidar/imu를 포함한 20개 link, 19개 joint입니다. 실제 구성은 `MANIFEST.json`을 확인합니다.

RViz에서 확인한 기본 자세는 wrist_roll=-π/2 rad, 나머지 가동 관절=0 rad입니다.
URDF 자체는 초기 관절각을 지정하지 않으므로 다른 프로그램에서 이 자세를 보려면 별도로 설정합니다.

## 적용 범위

이 번들은 현재 ROS/RViz 모델을 고정 URDF로 내보낸 것입니다.
Isaac 전용 USD, 수동 롤러 충돌 구조, 추가 base 질량·관성 보정은 포함하지 않습니다.
Isaac Sim에서 물리 주행을 검증한 번들이 아닙니다.
카메라는 광학 좌표계와 외형이며 영상 센서를 생성하는 코드는 포함하지 않습니다.
장착값의 원본 `calibrated: false`와 손목 카메라의 wrist_roll 이전 장착 기준을 유지합니다.

## 재생성

Xacro를 사용할 수 있는 환경에서 이 폴더를 작업 경로로 실행합니다.

```bash
xacro source_xacro/urdf/lekiwi.urdf.xacro base_mesh_dir:=meshes/base soarm_mesh_dir:=meshes/soarm use_hardware_sensors:=false > lekiwi_soarm.urdf
```

하드웨어 프레임을 포함한 번들을 재생성할 때는 위 인자를 `use_hardware_sensors:=true`로 설정합니다.

현재 패키지의 Xacro·설정과 STL을 바이트 그대로 복사했습니다. 내보낸 URDF에서 mesh 경로만 상대 경로로 지정했습니다.
원본 교육용 프로젝트는 수정하지 않았습니다. 출처와 권리는 `provenance/` 및 `THIRD_PARTY_NOTICES.md`, 파일 해시는 `MANIFEST.json`에 있습니다.
